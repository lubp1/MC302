import java.awt.*;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;

public class Main{
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {


        ArrayList<Usuario> usuarios = new ArrayList<Usuario>();

        /*Salvando usuarios em usuarios.dat
        usuarios.add(new Usuario("Julio Kiyoshi", "378.457.598-64", "JulioK",
                     "JulioKY", "juliokiyoshi@unicamp.br"));
        usuarios.add(new Usuario("Lucas Bertoloto", "402.798.725-21", "LucasB",
                    "LucasBT", "lucasbertoloto@unicamp.br"));
        usuarios.add(new Usuario("Hugo Navarro", "564.211.629-84", "HugoN",
                    "HugoNV", "hugonavarro@unicamp.br"));
        usuarios.add(new Usuario("Danilo Miranda", "210.654.753-26", "DaniloM",
                    "DaniloMR", "danilomiranda@unicamp.br"));
        usuarios.add(new Usuario("Danilo Braz", "013.548.984.51", "DaniloB",
                    "DaniloBZ", "danilobraz@unicamp.br"));
        usuarios.add(new Usuario("Caio Dias", "159.219.256.78", "CaioD",
                    "CaioDS", "caiodias@unicamp.br"));

        moradias.add(new Casa(2100f, 1200.5f, "Perto de dois supermercados e uma academia", usuarios.get(0),
                    "Casa com duas suites, um lavabo e quintal grande", "Rua Dr Ricardo Qualquer", 2, 2, 2, 4, "Quintal espacoso com piscina",
                    110.70f));
        moradias.add(new Casa(1500f, 2000f, "Comercio ativo nas redondezas de negocios locais", usuarios.get(0),
                    "Casa com uma suite e um quarto, um lavabo", "Rua Unicamp 1", 2, 1, 2, 2, "Area de lazer nao tao grande, possui espaco verde mas sem piscina",
                    89.40f));
        moradias.add(new Casa(2700f, 300f, "Muito proximo da entrada da universidade e longe de republicas com muitas festas por ano", usuarios.get(0),
                    "Casa grande com tres quartos e quatro banheiros", "Rua Unicamp 2", 3, 0, 4, 4, "A casa eh muito espacosa tanto nos comodos internos quanto no quintal",
                    126.30f));

        moradias.add(new Apartamento(1200f, 1450f, "Area calma sem muito trafego de carros", usuarios.get(1),
                    "Apartamento que pega sol da manha e em andar alto", "Rua Unicamp 3", 16, 1, 87.80f, 67.90f, 2, 1,
                    3, true, "O predio oferece uma piscina para os moradores e varanda espacosa em cada apartamento", 2, 3));
        moradias.add(new Apartamento(870f, 2100f, "Torre proxima a supermercados e restaurantes", usuarios.get(1),
                    "Sala e cozinha espacosos", "Rua Unicamp 4", 3, 1, 71.80f, 64.50f, 1, 1,
                    2, false, "O predio possui um playground com mesa de bilhar e ping-pong", 1, 4));
        moradias.add(new Apartamento(1200f, 665f, "Proximo a universidade e a fast foods", usuarios.get(1),
                    "Apartamento confortavel ja mobiliado", "Rua Unicamo 5", 7, 2, 50.60f, 43.20f, 1, 1,
                    2, false, "Area para caminhar ao redor das duas torres", 3, 4));

        moradias.add(new Pensionato(1100f, 615f, "Rua calma e casa proxima a supermercados", usuarios.get(2),
                    "Casa grande com areas comuns muito espacosas", "Rua Unicamp 6", 130f, 8, false,
                    true, true, true));
        moradias.add(new Pensionato(650f, 420f, "Muito proximo da universidade, fora das avenidas principais", usuarios.get(2),
                    "Casa com poucos moradores e nova", "Rua Unicamp 7", 100f, 5, false,
                    false, true, false));
        moradias.add(new Pensionato(730f, 1000f, "Proximo a todo tipo de comercio de comida", usuarios.get(2),
                    "Casa conservada, quartos grandes e quintal espacoso", "Rua Unicamp 8", 145f, 6, true,
                    true, false, false));

        moradias.add(new Kitnet(1400f, 740f, "Lugar calmo com area verde proxima", usuarios.get(3),
                    "Kitnet ampla mobiliada com eletrodomesticos modernos", "Rua Unicamp 9", false, true, false, false,
                    true, true));
        moradias.add(new Kitnet(2000f, 200f, "Condominio fechado de kitnets bem localizado com muitos resturantes ao redor", usuarios.get(3)
                    , "Kitnet recem construida, pronta para o primeiro uso, possui ampla area e bonito design interior", "Rua Unicamp 9", true,
                    false, false, false, true, false));
        moradias.add(new Kitnet(800f, 560f, "Proximo a academia e fast foods", usuarios.get(3),
                    "Espaco medio, local coberto para o carro e area de servico em cada kitnet", "Rua Unicamp 10", true, false, true,
                    true, false, true));

        moradias.add(new Republica(500f, 250f, "Proximo ao centro de comercio local", usuarios.get(4),
                    "Casa grande, area de lazer ampla", "Rua Unicamp 11", true, true, 10, 1, true,
                    "A republica conta com mesa de bilhar, mesa pra beer-pong e ping-pong, e quintal grande com piscina", 120f));
        moradias.add(new Republica(620f, 430f, "Area grande so de casas, mas proximo a supermercados", usuarios.get(4),
                    "Casa com muitos quartos e banheiros para cada quarto", "Rua Unicamp 12", true, false, 8, 1, false,
                    "A casa conta com uma area de churrasqueira e piscina", 160f));
        moradias.add(new Republica(840f, 600f, "Proxima a academia e area verde", usuarios.get(4),
                    "Suites grandes compartilhados, sala de jantar e comodos grandes", "Rua Unicamp 13", false, true, 12, 1, true,
                    "Comodo grande separado para integracao dos moradores da casa e quinatl espacoso", 120f));

        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("usuarios.dat"));
            for (Usuario usuario : usuarios) {
                out.writeObject(usuario);
            }
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
        */

        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream(new FileInputStream("usuarios.dat"));
            while (true) {
                usuarios.add((Usuario) in.readObject());
            }
        } catch (EOFException e) {
            System.out.println(usuarios.size() + " usuarios cadastrados");
            try {
                in.close();
            } catch (Exception e1) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }




        sc.close();
    }

    public static Usuario cadastraUsuario() {
        System.out.println("Cadastro de Usuário: ");
        System.out.println("Insira seu nome: ");
        String nome = sc.nextLine();
        System.out.println("Insira seu CPF: ");
        String cpf = sc.nextLine();
        Usuario usuario = new Usuario(nome,cpf);
        System.out.println("Insira seu login: ");
        usuario.setLogin(sc.nextLine());
        for( ; true ;) {
            System.out.println("Insira sua senha: ");
            usuario.setSenha(sc.nextLine());
            System.out.println("Insira sua senha novamente: ");
            String senha2 = sc.nextLine();
            if (usuario.getSenha().equals(senha2))
                break;
            System.out.println("Senhas divergentes, digite novamente");

        }
        System.out.println("Insira seu e-mail: ");
        usuario.setEmail(sc.nextLine());
        System.out.println("Insira sua forma de pagamento:(Boleto, Online, Em especie)");
        String pagamento = sc.nextLine();
        if(pagamento.equals("Boleto"))
            usuario.adicionarFormasPagamento(Pagamento.Boleto);
        if(pagamento.equals("Online"))
            usuario.adicionarFormasPagamento(Pagamento.Online);
        if(pagamento.equals("Em especie"))
            usuario.adicionarFormasPagamento(Pagamento.EmEspecie);
        return usuario;
    }

    public static Locador cadastraLocador(Usuario user) {
        System.out.println("Insira seu ano de graduação: ");
        boolean erro = true;
        int graduacao = 0;
        do {
            try {
                graduacao = sc.nextInt();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um inteiro");
                sc.reset();
                sc.next();
            }
        } while (erro);

        erro = true;
        System.out.println("Deseja dividir quarto? ");
        boolean quarto = false;
        do {
            try {
                quarto = sc.nextBoolean();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um booleano (true ou false)");
                sc.reset();
                sc.next();
            }
        } while (erro);

        erro = true;
        System.out.println("Qual o preco minimo que você deseja pagar? ");
        float precomin = 1;
        do {
            try {
                precomin = sc.nextFloat();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um número real");
                sc.reset();
                sc.next();
            }
        } while (erro);


        erro = true;
        System.out.println("Qual o preco maximo que você deseja pagar? ");
        float precomax = 1;
        do {
            try {
                precomax = sc.nextFloat();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um número real");
                sc.reset();
                sc.next();
            }
        } while (erro);


        erro = true;
        System.out.println("Qual a menor distância em metros que você deseja morar? ");
        float distmin = 1;
        do {
            try {
                distmin = sc.nextFloat();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um número real");
                sc.reset();
                sc.next();
            }
        } while (erro);


        erro = true;
        System.out.println("Qual a maior distância em metros que você deseja morar? ");
        float distmax = 1;
        do {
            try {
                distmax = sc.nextFloat();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um número real");
                sc.reset();
                sc.next();
            }
        } while (erro);


        erro = true;
        System.out.println("Você tem animais? ");
        boolean animal = false;
        do {
            try {
                animal = sc.nextBoolean();
                erro = false;
            } catch (java.util.InputMismatchException e) {
                System.err.println("Insira um booleano (true ou false)");
                sc.reset();
                sc.next();
            }
        } while (erro);

        sc.nextLine();
        return new Locador(graduacao, quarto, precomin, precomax, distmin, distmax, animal);
    }


    public static Locatario cadastraLocatario(Usuario user) {
        return new Locatario();
    }

    public static Usuario login(ArrayList<Usuario> usuarios) {
        for( ; true; ) {
            System.out.println("Insira seu login: ");
            String login = sc.nextLine();
            System.out.println("Insira sua senha: ");
            String senha = sc.nextLine();
            for(Usuario user: usuarios) {
                if (user.getLogin().equals(login) && user.getSenha().equals(senha)) {
                    System.out.println("Seja bem-vindo " + user.getNome());
                    return user;
                }
            }
            System.out.println("Login ou senha incorretos, tente novamente");
        }
    }

    public static Moradia cadastrarMoradia(Usuario dono) {
        for( ; true; ) {
            System.out.println("Insira o numero do tipo de moradia: ");
            System.out.println("1-Casa");
            System.out.println("2-Kitnet");
            System.out.println("3-Pensionato");
            System.out.println("4-Republica");
            System.out.println("5-Apartamento");
            int tipo = sc.nextInt();
            if (tipo == 1) {
                System.out.println("Insira o preco: ");
                float preco = sc.nextFloat();
                System.out.println("Insira a distancia da universidade: ");
                float distanciauni = sc.nextFloat();
                System.out.println("Insira uma descricao dos arredores da casa: ");
                sc.nextLine();
                String descricaoArredores = sc.nextLine();
                System.out.println("Insira uma descricao da casa: ");
                String descricaoCasa = sc.nextLine();
                System.out.println("Insira o endereço da casa: ");
                String endereco = sc.nextLine();
                System.out.println("Insira a quantidade de quartos: ");
                int quartos = sc.nextInt();
                System.out.println("Insira a quantidade de suites: ");
                int suites = sc.nextInt();
                System.out.println("Insira a quantidade de banheiros: ");
                int banheiros = sc.nextInt();
                System.out.println("Insira a quantidade de vagas de carro: ");
                int vagas = sc.nextInt();
                sc.nextLine();
                System.out.println("Insira uma descrição das áreas de lazer: ");
                String lazer = sc.nextLine();
                System.out.println("Quantos metros quadrados a casa tem? ");
                float area = sc.nextFloat();
                Casa casa = new Casa(preco, distanciauni, descricaoArredores, dono, descricaoCasa, endereco, quartos, suites, banheiros, vagas, lazer, area);
                dono.getLocatario().adicionarMoradia(casa);
                System.out.println("Casa cadastrada com sucesso!");
                return casa;
            } else if (tipo == 2) {
                System.out.println("Insira o preco: ");
                float preco = sc.nextFloat();
                System.out.println("Insira a distancia da universidade: ");
                float distanciauni = sc.nextFloat();
                sc.nextLine();
                System.out.println("Insira uma descricao dos arredores da Kitnet: ");
                String descricaoArredores = sc.nextLine();
                System.out.println("Insira uma descricao da Kitnet: ");
                String descricaoKitnet = sc.nextLine();
                System.out.println("Insira o endereço da Kitnet: ");
                String endereco = sc.nextLine();
                System.out.println("Possui vaga de carro?(true ou false)");
                boolean vagas = sc.nextBoolean();
                System.out.println("A conta de luz é separada?(true ou false)");
                boolean luz = sc.nextBoolean();
                System.out.println("A conta de agua é separada?(true ou false)");
                boolean agua = sc.nextBoolean();
                System.out.println("A conta de internet é separada?(true ou false)");
                boolean internet = sc.nextBoolean();
                System.out.println("A Kitnet é mobiliada?(true ou false)");
                boolean mobiliado = sc.nextBoolean();
                System.out.println("Aceita animais?(true ou false)");
                boolean animal = sc.nextBoolean();
                Kitnet kitnet = new Kitnet(preco, distanciauni, descricaoArredores, dono, descricaoKitnet, endereco, vagas, luz, agua, internet, mobiliado, animal);
                dono.getLocatario().adicionarMoradia(kitnet);
                System.out.println("Kitnet cadastrada com sucesso!");
                return kitnet;
            } else if (tipo == 3) {
                System.out.println("Insira o preco: ");
                float preco = sc.nextFloat();
                System.out.println("Insira a distancia da universidade: ");
                float distanciauni = sc.nextFloat();
                sc.nextLine();
                System.out.println("Insira uma descricao dos arredores do pensionato: ");
                String descricaoArredores = sc.nextLine();
                System.out.println("Insira uma descricao do pensionato: ");
                String descricaoPensionato = sc.nextLine();
                System.out.println("Insira o endereço do pensionato: ");
                String endereco = sc.nextLine();
                System.out.println("Insira o preço médio do rateio: ");
                float rateio = sc.nextFloat();
                System.out.println("Insira a quantidade de moradores: ");
                int pessoas = sc.nextInt();
                System.out.println("O quarto é compartilhado?(true ou false) ");
                boolean compartilhado = sc.nextBoolean();
                System.out.println("O quarto é suite?(true ou false) ");
                boolean suite = sc.nextBoolean();
                System.out.println("A limpeza está inclusa no preço?(true ou false) ");
                boolean limpeza = sc.nextBoolean();
                System.out.println("A alimentação está inclusa?(true ou false) ");
                boolean alimentacao = sc.nextBoolean();
                Pensionato pensionato = new Pensionato(preco, distanciauni, descricaoArredores, dono, descricaoPensionato, endereco, rateio, pessoas, compartilhado, suite, limpeza, alimentacao);
                dono.getLocatario().adicionarMoradia(pensionato);
                System.out.println("Pensionato cadastrado com sucesso!");
                return pensionato;
            } else if (tipo == 4) {
                System.out.println("Insira o preco: ");
                float preco = sc.nextFloat();
                System.out.println("Insira a distancia da universidade: ");
                float distanciauni = sc.nextFloat();
                sc.nextLine();
                System.out.println("Insira uma descricao dos arredores da Repúbliac: ");
                String descricaoArredores = sc.nextLine();
                System.out.println("Insira uma descricao da República: ");
                String descricaoRepublica = sc.nextLine();
                System.out.println("Insira o endereço da República: ");
                String endereco = sc.nextLine();
                System.out.println("A República aceita festas? (true ou false)");
                boolean festas = sc.nextBoolean();
                System.out.println("A República aceita animais? (true ou false)");
                boolean animal = sc.nextBoolean();
                System.out.println("Quantas pessoas moram na República? ");
                int moradores = sc.nextInt();
                System.out.println("Quantas vagas de hospedes? ");
                int hospedes = sc.nextInt();
                System.out.println("O banheiro é compartilhado? (true ou false)");
                boolean banheiro = sc.nextBoolean();
                sc.nextLine();
                System.out.println("Insira uma descrição das áreas de lazer: ");
                String lazer = sc.nextLine();
                System.out.println("Qual o preco medio do rateio? ");
                float rateio = sc.nextFloat();
                Republica republica = new Republica(preco, distanciauni, descricaoArredores, dono, descricaoRepublica, endereco, festas, animal, moradores, hospedes, banheiro, lazer, rateio);
                dono.getLocatario().adicionarMoradia(republica);
                System.out.println("República cadastrada com sucesso!");
                return republica;
            } else if (tipo == 5) {
                System.out.println("Insira o preco: ");
                float preco = sc.nextFloat();
                System.out.println("Insira a distancia da universidade: ");
                float distanciauni = sc.nextFloat();
                sc.nextLine();
                System.out.println("Insira uma descricao dos arredores do apartamento: ");
                String descricaoArredores = sc.nextLine();
                System.out.println("Insira uma descricao do apartamento: ");
                String descricaoRepublica = sc.nextLine();
                System.out.println("Insira o endereço do apartamento: ");
                String endereco = sc.nextLine();
                System.out.println("Em que andar está o apartamento? ");
                int andar = sc.nextInt();
                System.out.println("Quantas vagas de carro tem? ");
                int vagas = sc.nextInt();
                System.out.println("Quantos metros quadrados o apartamento tem? ");
                float metragem = sc.nextFloat();
                System.out.println("Quantos metros quadrados o apartamento tem de area util? ");
                float areaUtil = sc.nextFloat();
                System.out.println("Quantas suites o apartamento tem? ");
                int suites = sc.nextInt();
                System.out.println("Quantos quartos o apartamento tem? ");
                int quartos = sc.nextInt();
                System.out.println("Quantos banheiros o apartamento tem? ");
                int banheiros = sc.nextInt();
                System.out.println("Possui deposito? (true ou false)");
                boolean deposito = sc.nextBoolean();
                sc.nextLine();
                System.out.println("Insira uma descrição das áreas de lazer: ");
                String lazer = sc.nextLine();
                System.out.println("Quantas torres o predio tem? ");
                int torres = sc.nextInt();
                System.out.println("Quantos apartamentos tem no andar? ");
                int apandar = sc.nextInt();
                Apartamento apartamento = new Apartamento(preco, distanciauni, descricaoArredores, dono, descricaoRepublica, endereco, andar, vagas, metragem, areaUtil, suites, quartos, banheiros, deposito, lazer, torres, apandar);
                dono.getLocatario().adicionarMoradia(apartamento);
                System.out.println("Apartamento cadastrado com sucesso!");
                return apartamento;
            } else {
                System.out.println("Número incorreto, tente novamente");

            }
        }
    }

    public static void listarMordias(ArrayList<Moradia> moradias, Locador locador) {
        System.out.println("Moradias disponíveis com as suas preferências:");
        for(Moradia moradia: moradias) {
            if(moradia.getDistanciaUniversidade()<locador.getDistMax() && moradia.getDistanciaUniversidade()>locador.getDistMin() && moradia.getPreco()<locador.getPrecoMax()
                    && moradia.getPreco()>locador.getPrecoMin()) {
                System.out.println(moradia);
            }
        }
    }

}
