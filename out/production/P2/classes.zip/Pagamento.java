public enum Pagamento {
    Online,Boleto,EmEspecie;
}
