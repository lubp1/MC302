public interface Arquivo {
    public void salvarEmArquivo(String filename);
}
